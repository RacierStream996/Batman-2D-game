
Batman: Shadow of Gotham — Prototype
===================================

What's included:
- index.html (Phaser 3 via CDN)
- main.js (game logic with 20 level configurations, simple enemies, bosses)
- This is a lightweight prototype with placeholder graphics generated at runtime (shapes / colors).
- Controls:
  - Left / Right arrows: move
  - Up or W: jump
  - J: attack (batarang)
  - K: grapple (teleport toward mouse pointer within range)
  - R: restart level

How to run:
1. Download and unzip the files.
2. Open index.html in a modern browser (Chrome/Edge/Firefox). Phaser is loaded from a CDN so an internet connection is required.
3. Play!

Notes:
- This is a prototype scaffold. If you want, I can:
  - Improve visuals (pixel art or hand-painted sprites).
  - Add music and SFX.
  - Implement more detailed boss mechanics, collectibles, and polish.
  - Export to a hosted playable link (requires hosting; I can suggest free hosting options or help deploy to Github Pages).
